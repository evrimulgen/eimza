package tr.gov.tubitak.bilgem.esya.android.signexample;

import android.content.Context;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import tr.gov.tubitak.uekae.esya.api.asn.x509.ECertificate;

import javax.smartcardio.CardTerminal;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: ramazan.girgin
 * Date: 12/7/12
 * Time: 9:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class CertListAdapter extends BaseAdapter implements View.OnClickListener {
    private Context context;
    private Pair<CardTerminal,ECertificate> selection;

    private List<Pair<CardTerminal,ECertificate>> certificateList=new ArrayList<Pair<CardTerminal, ECertificate>>();

    public CertListAdapter(Context context) {
        this.context = context;
    }

    public int getCount() {
        return certificateList.size();
    }

    public Object getItem(int position) {
        return certificateList.get(position);
    }

    public long getItemId(int position) {
        return position;
    }

    public void addItem(CardTerminal cardTerminal,ECertificate certificate){
        certificateList.add(new Pair<CardTerminal, ECertificate>(cardTerminal,certificate));
    }

    public View getView(int position, View convertView, ViewGroup viewGroup) {
        Pair<CardTerminal,ECertificate> entry = certificateList.get(position);
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.cert_tree_row, null);
        }

        ECertificate eCertificate = entry.second;

        TextView tvId = (TextView) convertView.findViewById(R.id.tvIdNumber);
        tvId.setText(eCertificate.getSubject().getSerialNumberAttribute());

        TextView tvNameAndSurname = (TextView) convertView.findViewById(R.id.tvNameAndSurname);
        tvNameAndSurname.setText(eCertificate.getSubject().getCommonNameAttribute());

        TextView tvQualifiedStatus = (TextView) convertView.findViewById(R.id.tvQulifiedStatus);
        if(eCertificate.isQualifiedCertificate()){
            tvQualifiedStatus.setText("Nitelikli Sertifika");
        }
        else
        {
            tvQualifiedStatus.setText("Nitelikli Olmayan Sertifika");
        }

        CheckBox selectedBox = (CheckBox) convertView.findViewById(R.id.cb_selected_cert);
        selectedBox.setTag(entry);
        selectedBox.setOnClickListener(this);
        selectedBox.setChecked(false);
        if(selection == null)
        {
            selectedBox.setChecked(true);
            selection = entry;
        }
        else
        {
            if(selection == entry)
            {
                selectedBox.setChecked(true);
            }
        }
        return convertView;
    }

    public Pair<CardTerminal,ECertificate> getSelection(){
        return selection;
    }

    @Override
    public void onClick(View view) {
        Pair<CardTerminal,ECertificate> selectedItem = (Pair<CardTerminal, ECertificate>) view.getTag();
        selection  = selectedItem;
        notifyDataSetChanged();
    }
}
