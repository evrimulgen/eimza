package tr.gov.tubitak.uekae.esya.api.xades.example.profiles;

import org.junit.Test;
import tr.gov.tubitak.uekae.esya.api.asn.x509.ECertificate;
import tr.gov.tubitak.uekae.esya.api.certificate.validation.policy.PolicyReader;
import tr.gov.tubitak.uekae.esya.api.signature.SignatureType;
import tr.gov.tubitak.uekae.esya.api.signature.certval.CertValidationPolicies;
import tr.gov.tubitak.uekae.esya.api.smartcard.example.SmartCardManager;
import tr.gov.tubitak.uekae.esya.api.xades.example.utils.SampleBase;
import tr.gov.tubitak.uekae.esya.api.xades.example.validation.Validation;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.Context;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.SignatureMethod;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.XMLSignature;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.XMLSignatureException;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.document.FileDocument;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

/**
 * Profile 3 sample
 * @author suleyman.uslu
 */
public class P3 extends SampleBase {

    public static final String SIGNATURE_FILENAME = "p3.xml";

    /**
     * Creates T type signature according to the profile 3 specifications. It must be
     * upgraded to XL type using the second function (upgradeP3). If 'use-validation-
     * data-published-after-creation' is true in xml signature config file, after signing,
     * at least one new CRL for signing certificate must be published before upgrade.
     * @throws Exception
     */
    @Test
    public void createP3() throws Exception
    {
        try {
            // create context with working directory
            Context context = createContext();

            // add resolver to resolve policies
            context.addExternalResolver(POLICY_RESOLVER);

            // create signature according to context,
            // with default type (XADES_BES)
            XMLSignature signature = new XMLSignature(context);

            // add document as reference, but do not embed it
            // into the signature (embed=false)
            signature.addDocument("./sample.txt", "text/plain", false);

            signature.getSignedInfo().setSignatureMethod(SignatureMethod.RSA_SHA256);

            // false-true gets non-qualified certificates while true-false gets qualified ones
            ECertificate cert = SmartCardManager.getInstance().getSignatureCertificate(IS_QUALIFIED, !IS_QUALIFIED);

            // add certificate to show who signed the document
            signature.addKeyInfo(cert);

            // set time now
            signature.setSigningTime(Calendar.getInstance());

            // set policy info defined and required by profile
            signature.setPolicyIdentifier(OID_POLICY_P3,
                    "Uzun Dönemli ve SİL Kontrollü Güvenli Elektronik İmza Politikası",
                    "http://www.tk.gov.tr/bilgi_teknolojileri/elektronik_imza/dosyalar/Elektronik_Imza_Kullanim_Profilleri_Rehberi.pdf"
            );

         	// now sign it by using smart card
            signature.sign(SmartCardManager.getInstance().getSigner(PIN, cert));

            // upgrade to T
            signature.upgrade(SignatureType.ES_T);

            signature.write(new FileOutputStream(BASE_DIR + "p3_temp.xml"));
        }
        catch (XMLSignatureException x){
            // cannot create signature
            x.printStackTrace();
        }
        catch (IOException x){
            // probably couldn't write to the file
            x.printStackTrace();
        }
    }

    /**
     * Upgrades temporary T type signature to XL to create a signature with
     * profile 3 specifications. Do not run this upgrade code to be able to
     * validate using 'use-validation-data-published-after-creation' true
     * 'just after' creating temporary signature in the above function (createP3).
     * Wait for at least one new CRL for signing certificate to be published.
     * Also, revocation data must be CRL instead of OCSP in this profile.
     * @throws Exception
     */
    @Test
    public void upgradeP3() throws Exception {

        // create context with working directory
        Context context = createContext();
        
        // set policy such that it only works with CRL
        CertValidationPolicies policies = new CertValidationPolicies();
        policies.register(null, PolicyReader.readValidationPolicy(POLICY_FILE_CRL));

        context.getConfig().getValidationConfig().setCertValidationPolicies(policies);

        // add resolver to resolve policies
        context.addExternalResolver(POLICY_RESOLVER);

        // read temporary signature
        XMLSignature signature = XMLSignature.parse(new FileDocument(new File(BASE_DIR + "p3_temp.xml")),context);

        // upgrade to XL
        signature.upgrade(SignatureType.ES_XL);

        signature.write(new FileOutputStream(BASE_DIR + SIGNATURE_FILENAME));
    }

    @Test
    public void validate() throws Exception {
        Validation.validate(SIGNATURE_FILENAME);
    }
}
