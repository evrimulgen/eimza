package tr.gov.tubitak.uekae.esya.api.xades.example.utils;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import tr.gov.tubitak.uekae.esya.api.asn.x509.ECertificate;
import tr.gov.tubitak.uekae.esya.api.common.ESYAException;
import tr.gov.tubitak.uekae.esya.api.common.crypto.BaseSigner;
import tr.gov.tubitak.uekae.esya.api.crypto.alg.SignatureAlg;
import tr.gov.tubitak.uekae.esya.api.signature.util.PfxSigner;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.Context;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.XMLSignature;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.XMLSignatureException;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.config.Config;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.resolver.OfflineResolver;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.net.URL;

/**
 * Represents a base for signature samples
 * @author suleyman.uslu
 */
public class SampleBase
{
    protected static String ROOT_DIR;           // root directory of project
    protected static String CONFIG;             // config file path
    protected static String BASE_DIR;           // base directory where signatures created
    protected static String POLICY_FILE;        // certificate validation policy file path
    protected static String POLICY_FILE_CRL;    // path of policy file without OCSP
    protected static String PFX_FILE;           // PFX file path
    protected static String PFX_PASS;           // PFX password
    protected static String PIN;                // smart card PIN

    protected static ECertificate CERTIFICATE;  // certificate of PFX
    protected static BaseSigner SIGNER;         // signer of PFX

    protected static boolean IS_QUALIFIED;      // true if qualified certificates to be used

    protected static OfflineResolver POLICY_RESOLVER;   // policy resolver for profile examples

    public static final int[] OID_POLICY_P2 = new int[]{2,16,792,1,61,0,1,5070,3,1,1};
    public static final int[] OID_POLICY_P3 = new int[]{2,16,792,1,61,0,1,5070,3,2,1};
    public static final int[] OID_POLICY_P4 = new int[]{2,16,792,1,61,0,1,5070,3,3,1};

    private static final String ENVELOPE_XML =  // sample XML document used for enveloped signature
                    "<envelope>\n" +
                    "  <data id=\"data1\">\n" +
                    "    <item>Item 1</item>\n"+
                    "    <item>Item 2</item>\n"+
                    "    <item>Item 3</item>\n"+
                    "  </data>\n" +
                    "</envelope>\n";

    /**
     * Initialize paths and other variables
     */
    static {

        URL root = SampleBase.class.getResource("/");
        String classPath = root.getPath();
        File binDir = new File(classPath);
        ROOT_DIR = binDir.getParent();

        BASE_DIR = ROOT_DIR + "/testdata/";
        CONFIG = ROOT_DIR + "/config/xmlsignature-config.xml";
        POLICY_FILE = ROOT_DIR + "/config/certval-policy-test.xml";
        POLICY_FILE_CRL = ROOT_DIR + "/config/certval-policy-test-crl.xml";
        PFX_FILE = ROOT_DIR + "/sertifika deposu/356265_test1@kamusm.gov.tr.pfx";
        PFX_PASS = "356265";

        PfxSigner signer = new PfxSigner(SignatureAlg.RSA_SHA256, PFX_FILE, PFX_PASS.toCharArray());
        CERTIFICATE = signer.getSignersCertificate();
        SIGNER = signer;

        PIN = "12345";

        IS_QUALIFIED = true;

        System.out.println("Base dir : " + BASE_DIR);

        POLICY_RESOLVER = new OfflineResolver();
        POLICY_RESOLVER.register("urn:oid:2.16.792.1.61.0.1.5070.3.1.1", ROOT_DIR + "/config/profiller/Elektronik_Imza_Kullanim_Profilleri_Rehberi.pdf", "text/plain");
        POLICY_RESOLVER.register("urn:oid:2.16.792.1.61.0.1.5070.3.2.1", ROOT_DIR + "/config/profiller/Elektronik_Imza_Kullanim_Profilleri_Rehberi.pdf", "text/plain");
        POLICY_RESOLVER.register("urn:oid:2.16.792.1.61.0.1.5070.3.3.1", ROOT_DIR + "/config/profiller/Elektronik_Imza_Kullanim_Profilleri_Rehberi.pdf", "text/plain");
    }

    /**
     * Creates context for signature creation and validation
     * @return created context
     */
    public static Context createContext() {
    	
    	Context context = null;
    	try {
			context = new Context(BASE_DIR);
			context.setConfig(new Config(CONFIG));
		} catch (XMLSignatureException e) {
			e.printStackTrace();
		}
    	return context;
    }

    /**
     * Creates sample envelope XML that will contain signature inside
     * @return envelope in Document format
     * @throws tr.gov.tubitak.uekae.esya.api.common.ESYAException
     */
    public Document newEnvelope() throws ESYAException {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            DocumentBuilder db = dbf.newDocumentBuilder();

            return db.parse(new ByteArrayInputStream(ENVELOPE_XML.getBytes()));
        }
        catch (Exception x){
            // we shouldn't be here if ENVELOPE_XML is valid
            x.printStackTrace();
        }
        throw new ESYAException("Cant construct envelope xml ");
    }

    /**
     * Reads an XML document into DOM document format
     * @param uri XML file to be read
     * @param aContext signature context
     * @return DOM document format of read XML document
     * @throws Exception
     */
    public org.w3c.dom.Document parseDoc(String uri, Context aContext) throws Exception {

        // generate document builders for parsing
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder db = dbf.newDocumentBuilder();

        // open the document
        File f = new File(BASE_DIR + uri);

        // parse into DOM format
        org.w3c.dom.Document document = db.parse(f);
        aContext.setDocument(document);

        return document;
    }

    /**
     * Gets the signature by searching for tag in an enveloped signature
     * @param aDocument XML document to be looked for
     * @param aContext signature context
     * @return XML signature in the XML document
     * @throws Exception
     */
    public XMLSignature readSignature(org.w3c.dom.Document aDocument, Context aContext) throws Exception {

        // get the signature in enveloped signature format
        Element signatureElement = ((Element)aDocument.getDocumentElement().getElementsByTagName("ds:Signature").item(0));

        // return the XML signature created with signature element
        return new XMLSignature(signatureElement, aContext);
    }

    /**
     * Gets the signature by searching for tag in a parallel signature
     * @param aDocument XML document to be looked for
     * @param aContext signature context
     * @param item order of signature to be read in parallel structure
     * @return XML signature in the XML document
     * @throws Exception
     */
    public XMLSignature readSignature(org.w3c.dom.Document aDocument, Context aContext, int item) throws Exception {

        // get the first signature element searching for the tag in the XML document
        Element signatureElement = ((Element)((Element)aDocument.getDocumentElement().getElementsByTagName("signatures").item(0)).getElementsByTagName("ds:Signature").item(item));

        // return the XML signature using signature element
        return new XMLSignature(signatureElement, aContext);
    }
}
