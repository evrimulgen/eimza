package tr.gov.tubitak.uekae.esya.api.pades.example;

import org.junit.Test;
import tr.gov.tubitak.uekae.esya.api.signature.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Calendar;

/**
 * @author ayetgin
 */
public class BasicTest extends PadesBaseTest {

    @org.junit.Test
    public void validateSignedPdf() throws Exception {
        SignatureContainer sc = SignatureFactory.readContainer(new FileInputStream(BASE_DIR + "signed-bes.pdf"), createContext());
        ContainerValidationResult svr = sc.verifyAll();
        System.out.println(svr);
        assert svr.getResultType() == ContainerValidationResultType.ALL_VALID;
    }

    @Test
    public void signBES() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES, new FileInputStream(DATA_FILE), createContext());

        // add signature
        Signature signature = pc.createSignature(CERTIFICATE);
        signature.setSigningTime(Calendar.getInstance());
        signature.sign(SIGNER);
        pc.write(new FileOutputStream(BASE_DIR + "signed-bes.pdf"));

        // read and validate
        SignatureContainer pc2 = SignatureFactory.readContainer(SignatureFormat.PAdES, new FileInputStream(BASE_DIR + "signed-bes.pdf"), createContext());
        ContainerValidationResult svr = pc2.verifyAll();
        System.out.println(svr);
        assert svr.getResultType() == ContainerValidationResultType.ALL_VALID;
    }

    @Test
    public void readWriteTest() throws Exception {
        SignatureContainer sc = SignatureFactory.readContainer(new FileInputStream(BASE_DIR + "signed-bes.pdf"), createContext());

        sc.write(new FileOutputStream(BASE_DIR + "signed-rewrite.pdf"));
    }

}
