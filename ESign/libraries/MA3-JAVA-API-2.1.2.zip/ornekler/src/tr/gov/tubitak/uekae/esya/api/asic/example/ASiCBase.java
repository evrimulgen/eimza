package tr.gov.tubitak.uekae.esya.api.asic.example;

import tr.gov.tubitak.uekae.esya.api.asn.x509.ECertificate;
import tr.gov.tubitak.uekae.esya.api.common.crypto.BaseSigner;
import tr.gov.tubitak.uekae.esya.api.signature.Context;
import tr.gov.tubitak.uekae.esya.api.signature.SignatureFormat;
import tr.gov.tubitak.uekae.esya.api.signature.SignatureType;
import tr.gov.tubitak.uekae.esya.api.signature.config.Config;
import tr.gov.tubitak.uekae.esya.api.signature.sigpackage.PackageType;
import tr.gov.tubitak.uekae.esya.api.signature.sigpackage.SignaturePackage;
import tr.gov.tubitak.uekae.esya.api.signature.sigpackage.SignaturePackageFactory;
import tr.gov.tubitak.uekae.esya.api.smartcard.example.SmartCardManager;

import java.io.File;
import java.net.URL;

/**
 * Provides required variables and functions for ASiC examples
 * @author suleyman.uslu
 */
public class ASiCBase {

    protected static String ROOT_DIR;           // root directory of project
    protected static String BASE_DIR;           // base directory where signatures created

    protected static File DATA_FILE;            // file to be signed

    protected static ECertificate CERTIFICATE;  // certificate
    protected static BaseSigner SIGNER;         // signer

    protected static boolean IS_QUALIFIED = true;      // gets only qualified certificates in smart card
    protected static String PIN = "12345";                // PIN of the smart card
    
    static {

        URL root = ASiCBase.class.getResource("/");
        String classPath = root.getPath();
        File binDir = new File(classPath);
        ROOT_DIR = binDir.getParent();

        BASE_DIR = ROOT_DIR + "/testdata/";
        DATA_FILE = new File(BASE_DIR + "sample.txt");


        try {
			CERTIFICATE = SmartCardManager.getInstance().getSignatureCertificate(IS_QUALIFIED, !IS_QUALIFIED);
			SIGNER = SmartCardManager.getInstance().getSigner(PIN, CERTIFICATE);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        /* To sign with pfx file
        String PFX_FILE = ROOT_DIR + "/sertifika deposu/356265_test1@kamusm.gov.tr.pfx";
        String PFX_PASS = "356265";
        PfxSigner signer = new PfxSigner(SignatureAlg.RSA_SHA256, PFX_FILE, PFX_PASS.toCharArray());
        CERTIFICATE = signer.getSignersCertificate();
        SIGNER = signer;
        */
    }

    /**
     * Creates an appropriate file name for ASiC signatures
     * @param packageType    package type of the signature, ASiC_S or ASiC_E
     * @param format         format of the signature, CAdES or XAdES
     * @param type           type of the signature, BES etc.
     * @return file name of associated signature as string
     */
    protected String fileName(PackageType packageType, SignatureFormat format, SignatureType type){
        String fileName = BASE_DIR + packageType + "-"+format.name() + "-" +type;
        switch (packageType){
            case ASiC_S : return fileName + ".asics";
            case ASiC_E : return fileName + ".asice";
        }
        return null;
    }

    /**
     * Reads an ASiC signature
     * @param packageType     type of the ASiC signature to be read, ASiC_S or ASiC_E
     * @param format          format of the ASiC signature to be read, CAdES or XAdES
     * @param type            type of the ASiC signature to be read, BES etc.
     * @return signature package of ASiC signature
     * @throws Exception
     */
    protected SignaturePackage read(PackageType packageType, SignatureFormat format, SignatureType type) throws Exception
    {
        Context c = createContext();
        File f = new File(fileName(packageType, format, type));
        return SignaturePackageFactory.readPackage(c, f);
    }

    /**
     * Creates context for signature creation and validation
     * @return created context
     */
    public Context createContext(){
        Context c = new Context(new File(BASE_DIR).toURI());
        c.setConfig(new Config(ROOT_DIR + "/config/esya-signature-config.xml"));
        //c.setData(getContent()); //for detached CAdES signatures validation
        return c;
    }
}
