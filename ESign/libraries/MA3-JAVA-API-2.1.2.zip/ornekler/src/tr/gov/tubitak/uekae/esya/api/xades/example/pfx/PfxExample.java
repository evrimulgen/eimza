package tr.gov.tubitak.uekae.esya.api.xades.example.pfx;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import tr.gov.tubitak.uekae.esya.api.xades.example.utils.SampleBase;
import tr.gov.tubitak.uekae.esya.api.xades.example.validation.Validation;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.Context;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.XMLSignature;
import tr.gov.tubitak.uekae.esya.api.xmlsignature.XMLSignatureException;

import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Creating electronic signature using PFX
 * @author suleyman.uslu
 */
@RunWith(JUnit4.class)
public class PfxExample extends SampleBase
{

    public static final String SIGNATURE_FILENAME = "pfxexample.xml";

    /**
     * Creates detached BES with PFX
     * @throws Exception
     */
    @Test
    public void createDetachedBesWithPfx() throws Exception
    {
        try {
            // create context with working directory
            Context context = createContext();

            // create signature according to context,
            // with default type (XADES_BES)
            XMLSignature signature = new XMLSignature(context);

            // add document as reference, but do not embed it
            // into the signature (embed=false)
            signature.addDocument("./sample.txt", "text/plain", false);

            // add signer's certificate
            signature.addKeyInfo(CERTIFICATE);

            // sign the document
            signature.sign(SIGNER);

            signature.write(new FileOutputStream(BASE_DIR + SIGNATURE_FILENAME));
        }
        catch (XMLSignatureException x){
            // cannot create signature
            x.printStackTrace();
        }
        catch (IOException x){
            // probably couldn't write to the file
            x.printStackTrace();
        }
    }

    @Test
    public void validate() throws Exception {
        Validation.validate(SIGNATURE_FILENAME);
    }
}
