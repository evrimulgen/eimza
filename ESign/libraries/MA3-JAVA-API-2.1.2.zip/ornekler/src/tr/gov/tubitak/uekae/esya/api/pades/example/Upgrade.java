package tr.gov.tubitak.uekae.esya.api.pades.example;


import org.junit.Assert;
import org.junit.Test;
import tr.gov.tubitak.uekae.esya.api.pades.PAdESContext;
import tr.gov.tubitak.uekae.esya.api.signature.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Calendar;

/**
 * @author ayetgin
 */
public class Upgrade extends PadesBaseTest {

    @Test
    public void createEST() throws Exception {
        // read
        PAdESContext context = createContext();
        context.setSignWithTimestamp(true);
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES, new FileInputStream(DATA_FILE), context);

        // add signature
        Signature signature = pc.createSignature(CERTIFICATE);
        signature.setSigningTime(Calendar.getInstance());
        signature.sign(SIGNER);

        // write to file
        pc.write(new FileOutputStream(BASE_DIR + "signed-est.pdf"));
    }

    @Test
    public void upgradeBESToEST() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(new FileInputStream(BASE_DIR + "signed-bes.pdf"), createContext());

        // upgrade signature
        Signature signature = pc.getSignatures().get(0);
        signature.upgrade(SignatureType.ES_T);

        pc.write(new FileOutputStream(BASE_DIR + "signed-bes-to-est.pdf"));
    }

    @Test
    public void validateEST() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(BASE_DIR + "signed-est.pdf"), createContext());

        ContainerValidationResult cvr = pc.verifyAll();
        System.out.println(cvr);
        assert cvr.getResultType() == ContainerValidationResultType.ALL_VALID;
    }

    @Test
    public void validateEST2() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(BASE_DIR + "signed-bes-to-est.pdf"), createContext());


        ContainerValidationResult cvr = pc.verifyAll();
        System.out.println(cvr);
        assert cvr.getResultType() == ContainerValidationResultType.ALL_VALID;
    }

    @Test
    public void createLT() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(DATA_FILE), createContext());

        // add signature
        Signature signature = pc.createSignature(CERTIFICATE);
        signature.sign(SIGNER);

        // add timestamp
        signature.upgrade(SignatureType.ES_XL);
        pc.write(new FileOutputStream(BASE_DIR + "signed-lt.pdf"));
    }

    @Test
    public void createLTA() throws Exception {
        // read
        PAdESContext context = createContext();
        context.setSignWithTimestamp(true);
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(DATA_FILE), context);

        // add signature
        Signature signature = pc.createSignature(CERTIFICATE);
        signature.setSigningTime(Calendar.getInstance());
        signature.sign(SIGNER);

        // add timestamp
        signature.upgrade(SignatureType.ES_A);
        pc.write(new FileOutputStream(BASE_DIR + "signed-lta.pdf"));
    }

    @Test
    public void upgradeMiddle() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(BASE_DIR + "signed-lta.pdf"), createContext());

        // add signature
        Signature first = pc.getSignatures().get(0);

        // add timestamp
        Exception exception = null;
        try {
            first.upgrade(SignatureType.ES_A);
        } catch (Exception x){
            exception = x;
        }
        Assert.assertTrue("Cant upgrade signature if not last one", exception instanceof NotSupportedException);
    }

    @Test
    public void validateLT() throws Exception {
        // read
        Context c = createContext();
        c.getConfig().getCertificateValidationConfig().setUseValidationDataPublishedAfterCreation(false);
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(BASE_DIR + "signed-lt.pdf"), createContext());

        ContainerValidationResult cvr = pc.verifyAll();
        System.out.println(cvr);
        Assert.assertEquals(ContainerValidationResultType.ALL_VALID, cvr.getResultType());
    }

    @Test
    public void validateLTA() throws Exception {
        // read
        Context c = createContext();
        c.getConfig().getCertificateValidationConfig().setUseValidationDataPublishedAfterCreation(false);
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(BASE_DIR + "signed-lta.pdf"), createContext());

        ContainerValidationResult cvr = pc.verifyAll();
        System.out.println(cvr);
        Assert.assertEquals(cvr.getResultType(), ContainerValidationResultType.ALL_VALID);
    }

    @Test
    public void createLTAA() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(DATA_FILE), createContext());

        // add signature
        Signature signature = pc.createSignature(CERTIFICATE);
        signature.sign(SIGNER);

        // add timestamp
        signature.upgrade(SignatureType.ES_A);

        // get last signature which is timestamp
        signature = pc.getSignatures().get(pc.getSignatures().size()-1);
        signature.upgrade(SignatureType.ES_A);
        pc.write(new FileOutputStream(BASE_DIR + "signed-lta-a.pdf"));
    }

    @Test
    public void validateLTAA() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(SignatureFormat.PAdES,
                new FileInputStream(BASE_DIR + "signed-lta-a.pdf"), createContext());

        ContainerValidationResult cvr = pc.verifyAll();
        System.out.println(cvr);
        Assert.assertEquals(cvr.getResultType(), ContainerValidationResultType.ALL_VALID);
    }

}
