package tr.gov.tubitak.uekae.esya.api.pades.example;


import tr.gov.tubitak.uekae.esya.api.asn.x509.ECertificate;
import tr.gov.tubitak.uekae.esya.api.common.crypto.BaseSigner;
import tr.gov.tubitak.uekae.esya.api.crypto.alg.SignatureAlg;
import tr.gov.tubitak.uekae.esya.api.pades.PAdESContext;
import tr.gov.tubitak.uekae.esya.api.signature.config.Config;
import tr.gov.tubitak.uekae.esya.api.signature.util.PfxSigner;
import tr.gov.tubitak.uekae.esya.api.smartcard.example.SmartCardManager;

import java.io.File;
import java.net.URL;

/**
 * @author ayetgin
 */
public class PadesBaseTest {

    protected static BaseSigner SIGNER = null;
    protected static ECertificate CERTIFICATE = null;

    protected static String BASE_DIR;
    protected static String ROOT_DIR;
    protected static File DATA_FILE;

    protected static boolean IS_QUALIFIED = true;      // gets only qualified certificates in smart card
    protected static String PIN = "12345";                // PIN of the smart card
    
    static {
        URL root = PadesBaseTest.class.getResource("/");
        String classPath = root.getPath();
        File binDir = new File(classPath);
        ROOT_DIR = binDir.getParent();

        BASE_DIR = ROOT_DIR + "/testdata/";
        DATA_FILE = new File(BASE_DIR + "sample.pdf");

        try {
			CERTIFICATE = SmartCardManager.getInstance().getSignatureCertificate(IS_QUALIFIED, !IS_QUALIFIED);
			SIGNER=SmartCardManager.getInstance().getSigner(PIN, CERTIFICATE);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        /* To sign with pfx file
        String PFX_FILE = ROOT_DIR + "/sertifika deposu/356265_test1@kamusm.gov.tr.pfx";
        String PFX_PASS = "356265";
        PfxSigner signer = new PfxSigner(SignatureAlg.RSA_SHA256, PFX_FILE, PFX_PASS.toCharArray());
        CERTIFICATE = signer.getSignersCertificate();
        SIGNER = signer;
        */
    }

    /**
     * Creates context for signature creation and validation
     * @return created context
     */
    public static PAdESContext createContext(){
    	PAdESContext c = new PAdESContext(new File(BASE_DIR).toURI());
        c.setConfig(new Config(ROOT_DIR + "/config/esya-signature-config.xml"));
        return c;
    }

}
