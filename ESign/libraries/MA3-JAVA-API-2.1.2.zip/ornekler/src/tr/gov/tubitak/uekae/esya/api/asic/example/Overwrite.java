package tr.gov.tubitak.uekae.esya.api.asic.example;

import org.junit.Test;
import tr.gov.tubitak.uekae.esya.api.signature.*;
import tr.gov.tubitak.uekae.esya.api.signature.sigpackage.*;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Adds new signatures to given containers, new extended signature
 * will have the same name with the old one
 * @author suleyman.uslu
 */
public class Overwrite extends ASiCBase {

    @Test
    public void update_CAdES() throws Exception {

        SignaturePackage sp = read(PackageType.ASiC_E, SignatureFormat.CAdES, SignatureType.ES_BES);
        String fileName = fileName(PackageType.ASiC_E, SignatureFormat.CAdES, SignatureType.ES_BES)+"-upgraded.asice";
        File toUpgrade = new File(fileName);

        // create a copy tu update package
        sp.write(new FileOutputStream(fileName));

        // add signature
        SignaturePackage sp2 = SignaturePackageFactory.readPackage(createContext(), toUpgrade);
        SignatureContainer sc = sp2.createContainer();
        Signature s = sc.createSignature(CERTIFICATE);
        s.addContent(sp.getDatas().get(0), false);
        s.sign(SIGNER);

        // write onto read file!
        sp2.write();

        // read again to verify
        SignaturePackage sp3 = SignaturePackageFactory.readPackage(createContext(), new File(fileName));
        PackageValidationResult pvr = sp3.verifyAll();
        System.out.println(pvr);

        assert pvr.getResultType() == PackageValidationResultType.ALL_VALID;
    }
}