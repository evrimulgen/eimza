package tr.gov.tubitak.uekae.esya.api.pades.example;


import tr.gov.tubitak.uekae.esya.api.signature.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * @author ayetgin
 */
public class Multiple extends PadesBaseTest {

    @org.junit.Test
    public void signSequentalBES() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(new FileInputStream(DATA_FILE), createContext());

        // add signature
        Signature signature = pc.createSignature(CERTIFICATE);
        signature.sign(SIGNER);
        Signature signature2 = pc.createSignature(CERTIFICATE);
        signature2.sign(SIGNER);


        pc.write(new FileOutputStream(BASE_DIR + "signed-seq.pdf"));

        // read and validate
        SignatureContainer pc2 = SignatureFactory.readContainer(new FileInputStream(BASE_DIR + "signed-seq.pdf"), createContext());
        ContainerValidationResult cvr = pc2.verifyAll();
        System.out.println(cvr);
        assert cvr.getResultType() == ContainerValidationResultType.ALL_VALID;
    }

}
