package tr.gov.tubitak.uekae.esya.api.pades.example;


import org.junit.*;
import tr.gov.tubitak.uekae.esya.api.signature.*;
import tr.gov.tubitak.uekae.esya.api.signature.attribute.TimestampInfo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.List;

/**
 * @author ayetgin
 */
public class Props extends BasicTest {


    @org.junit.Test
    public void signBES() throws Exception {
        // read
        SignatureContainer pc = SignatureFactory.readContainer(new FileInputStream(DATA_FILE), createContext());

        // add signature
        Signature signature = pc.createSignature(CERTIFICATE);

        // set signing time
        Calendar signingTime = Calendar.getInstance();
        signingTime.set(Calendar.MILLISECOND, 0);
        signature.setSigningTime(signingTime);

        signature.sign(SIGNER);
        pc.write(new FileOutputStream(BASE_DIR + "props.pdf"));

        // read and validate
        SignatureContainer pc2 = SignatureFactory.readContainer(new FileInputStream(BASE_DIR + "props.pdf"), createContext());
        Calendar signingTimeRead = pc2.getSignatures().get(0).getSigningTime();

        assert signingTime.compareTo(signingTimeRead)==0; // equals dont work!

        ContainerValidationResult svr = pc2.verifyAll();
        System.out.println(svr);
        assert svr.getResultType() == ContainerValidationResultType.ALL_VALID;
    }

    @org.junit.Test
    public void testTimestampsInfoEST() throws Exception {
        SignatureContainer pc = SignatureFactory.readContainer(new FileInputStream(BASE_DIR + "signed-est.pdf"), createContext());
        List<TimestampInfo> all =  pc.getSignatures().get(0).getAllTimestampInfos();
        System.out.println(all);
        Assert.assertEquals(1, all.size());
    }

    @org.junit.Test
    public void testTimestampsInfoESA() throws Exception {
        SignatureContainer pc = SignatureFactory.readContainer(new FileInputStream(BASE_DIR + "signed-lta.pdf"), createContext());
        List<TimestampInfo> all =  pc.getSignatures().get(0).getAllTimestampInfos();
        System.out.println(all);
        Assert.assertEquals(2, all.size());
    }

}
