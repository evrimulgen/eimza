import tr.gov.tubitak.uekae.esya.api.asn.cms.ESignerIdentifier;
import tr.gov.tubitak.uekae.esya.api.asn.x509.ECertificate;
import tr.gov.tubitak.uekae.esya.api.common.ESYAException;
import tr.gov.tubitak.uekae.esya.api.common.crypto.Algorithms;
import tr.gov.tubitak.uekae.esya.api.crypto.alg.DigestAlg;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.MSSPClientConnector;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.PhoneNumberAndOperator;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.SigningMode;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.UserIdentifier;
import tr.gov.tubitak.uekae.esya.api.webservice.mssclient.wrapper.EMSSPRequestHandler;
import tr.gov.tubitak.uekae.esya.api.webservice.mssclient.wrapper.MSSParams;
import tr.gov.tubitak.uekae.esya.api.webservice.mssclient.wrapper.StringUtil;
import tr.gov.tubitak.uekae.esya.asn.cms.SigningCertificate;
import tr.gov.tubitak.uekae.esya.asn.cms.SigningCertificateV2;
import java.security.MessageDigest;
import java.security.spec.AlgorithmParameterSpec;


/**
 * Created with IntelliJ IDEA.
 * User: ramazan.girgin
 * Date: 8/1/12
 * Time: 2:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class EMobileSignerConnector implements MSSPClientConnector {
    EMSSPRequestHandler msspRequestHandler;
    public EMobileSignerConnector(MSSParams msspParams) {
        msspRequestHandler = new EMSSPRequestHandler(msspParams);
    }

	@Override
	public void setCertificateInitials(UserIdentifier userIdentifier) {
		try {
			msspRequestHandler.setCertificateInitials((PhoneNumberAndOperator) userIdentifier);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
    
    public String calculateFingerPrintValue(byte[] dataToBeSigned){
    	String retFingerPrintStr="";    	
        byte[] digestForSign = null;
        try {            
            MessageDigest digester = MessageDigest.getInstance(Algorithms.DIGEST_SHA1);
            digester.update(dataToBeSigned);
            digestForSign = digester.digest();            
        }
        catch (Exception exc){
        	System.out.println(exc); 
        	return null;
        }
        String digest4SignHex = StringUtil.toString(digestForSign);
        retFingerPrintStr = digest4SignHex.substring(digest4SignHex.length()-32);       
        return retFingerPrintStr;
    }
   
    @Override
    public byte[] sign(byte[] dataToBeSigned, SigningMode aMode, UserIdentifier aUserID, ECertificate eCertificate, String informativeText, String aSigningAlg, AlgorithmParameterSpec aParams) throws ESYAException {
    	String fingerPrintStr = calculateFingerPrintValue(dataToBeSigned);
    	if(fingerPrintStr == null){
    		throw new ESYAException("Parmak izi değeri hesaplanamadı.");
    	}
        byte [] retSignature = null;
        try {        	
        	
            retSignature = msspRequestHandler.sign(dataToBeSigned,aMode,(PhoneNumberAndOperator)aUserID,informativeText,aSigningAlg,aParams);            
        } catch (Exception e) {
            throw new ESYAException(e);
        }
        return retSignature;
    }

	@Override
	public ECertificate getSigningCert() {
		return msspRequestHandler.getSigningCert();
	}

	@Override
	public SigningCertificate getSigningCertAttr() {
		return msspRequestHandler.getSigningCertAttr();
	}

	@Override
	public SigningCertificateV2 getSigningCertAttrv2() {
		return msspRequestHandler.getSigningCertAttrv2();
	}

	@Override
	public ESignerIdentifier getSignerIdentifier() {
		return msspRequestHandler.getSignerIdentifier();
	}

	@Override
	public DigestAlg getDigestAlg() {
		return msspRequestHandler.getDigestAlg();
	}
}