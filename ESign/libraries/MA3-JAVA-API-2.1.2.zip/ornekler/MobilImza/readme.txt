* Örnek projelerde gerekli durumlarda jar,lisans ve politika dosya yolları proje ve kod  içinden değiştirilmelidir.
* Kullanım ile ilgili açıkklama https://yazilim.kamusm.gov.tr/esya-api/doku.php adresinde mobil imza  kısmında bulunabilir.

* Örnek projeler eclipse ortamında oluşturulmuştur.
* Projeleri derlemeden önce Eclipse'den tom cat 6 ve axis2 tanımlarının yapılması gerekmektedir.
  (http://blog.sencide.com/2011/06/create-web-service-using-apache-axis2.html) linki incelenebilir.
* Apache axis 2 kullanılarak web service ve client oluşturulmuştur.
* Örnek projelerin  çalıştırılması için gerekli diğer kütüphaneler Eclipse projesi ayarlarından bakılabilir.