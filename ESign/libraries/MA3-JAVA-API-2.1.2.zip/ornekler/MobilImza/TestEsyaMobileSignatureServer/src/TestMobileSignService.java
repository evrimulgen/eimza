import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import tr.gov.tubitak.uekae.esya.api.asn.cms.ESigningCertificate;
import tr.gov.tubitak.uekae.esya.api.asn.cms.ESigningCertificateV2;
import tr.gov.tubitak.uekae.esya.api.common.util.Base64;
import tr.gov.tubitak.uekae.esya.api.common.util.LicenseUtil;
import tr.gov.tubitak.uekae.esya.api.crypto.alg.SignatureAlg;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.Operator;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.PhoneNumberAndOperator;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.SigningMode;
import tr.gov.tubitak.uekae.esya.api.webservice.mssclient.wrapper.EMSSPRequestHandler;
import tr.gov.tubitak.uekae.esya.api.webservice.mssclient.wrapper.MSSParams;


public class TestMobileSignService {
    MSSParams mobilParams = new MSSParams("http://MImzaTubitakBilgem", "********", "www.turkcelltech.com");
    /*
    mobilParams.setMsspSignatureQueryUrl("http://mobilimza.corbuss.com.tr/MSSP2/services/MSS_Signature");
    //Test ortamı için "http://85.235.93.165/MSSP2/services/MSS_Signature"
    mobilParams.setMsspProfileQueryUrl("http://mobilimza.corbuss.com.tr/MSSP2/services/MSS_ProfileQueryPort");
    //Test ortamı için "http://85.235.93.165/MSSP2/services/MSS_ProfileQueryPort "
    */
    EMSSPRequestHandler msspRequestHandler = new EMSSPRequestHandler(mobilParams);
    
	private static final Map<Integer, Operator> intToTypeMap = new HashMap<Integer, Operator>();
	static {
	    for (Operator type : Operator.values()) {
	        intToTypeMap.put(type.ordinal(), type);
	    }
	}

	static Operator fromInt(int i) {
		Operator type = intToTypeMap.get(Integer.valueOf(i));
	    if (type == null) 
	        return Operator.TURKCELL;
	    return type;
	}
	
	  void loadLicense()
      {
		//write license path below
		  FileInputStream fis;
		try {
				fis = new FileInputStream("C:/Users/int2/Desktop/lisans.xml");
				String p = "1.3.15";
	          LicenseUtil.setLicenseXml(fis, p);
	          fis.close();
		} catch (Exception exc){
			// TODO Auto-generated catch block
			exc.printStackTrace();
		}		 
      }    
	  
      public void setCertificateInitials(String phoneNumber,int iOperator)
      {
    	  System.out.println("Servise geldi.");
          loadLicense();       
          Operator mobileOperator = fromInt(iOperator);          
          PhoneNumberAndOperator phoneNumberAndOperator = new PhoneNumberAndOperator(phoneNumber, mobileOperator);          
          try {
        	  msspRequestHandler.setCertificateInitials(phoneNumberAndOperator);
          } catch (Exception e) {
        	  e.printStackTrace();
        	  throw new RuntimeException(e);
          }
      }
      
      public String SignHash(String hashForSign64, String displayText,String phoneNumber, int iOperator)
      {
          loadLicense();
          Operator mobileOperator = fromInt(iOperator);
          PhoneNumberAndOperator phoneNumberAndOperator = new PhoneNumberAndOperator(phoneNumber, mobileOperator);
          byte[] dataForSign = Base64.decode(hashForSign64);
          byte[] signedData;
		try {
			signedData = msspRequestHandler.sign(dataForSign,SigningMode.SIGNHASH, phoneNumberAndOperator, displayText, SignatureAlg.RSA_SHA1.getName(),null);
		} catch (Exception e) {		
			e.printStackTrace();
			return null;
		}          
          return Base64.encode(signedData);
      }
  	  	
      public String getSigningCert() {
    	  return Base64.encode(msspRequestHandler.getSigningCert().getEncoded());
      }

      public String getSigningCertAttr() {
    	  ESigningCertificate sc = new ESigningCertificate(msspRequestHandler.getSigningCertAttr());
    	  return Base64.encode(sc.getEncoded());
      }

      public String getSigningCertAttrv2() {
    	  ESigningCertificateV2 scv2 = new ESigningCertificateV2(msspRequestHandler.getSigningCertAttrv2());
    	  return Base64.encode(scv2.getEncoded());
      }

      public String getSignerIdentifier() {
    	  return Base64.encode(msspRequestHandler.getSignerIdentifier().getEncoded());
      }

      public String getDigestAlg() {
    	  return msspRequestHandler.getDigestAlg().getName();
      }	
}
