package org.apache.ws.axis2;

import java.rmi.RemoteException;

public class TestMobileSignServicePortTypeProxy implements org.apache.ws.axis2.TestMobileSignServicePortType {
	private String _endpoint = null;
	private org.apache.ws.axis2.TestMobileSignServicePortType testMobileSignServicePortType = null;

	public TestMobileSignServicePortTypeProxy() {
		_initTestMobileSignServicePortTypeProxy();
	}

	public TestMobileSignServicePortTypeProxy(String endpoint) {
		_endpoint = endpoint;
		_initTestMobileSignServicePortTypeProxy();
	}

	private void _initTestMobileSignServicePortTypeProxy() {
		try {
			testMobileSignServicePortType = (new org.apache.ws.axis2.TestMobileSignServiceLocator()).getTestMobileSignServiceHttpSoap11Endpoint();
			if (testMobileSignServicePortType != null) {
				if (_endpoint != null)
					((javax.xml.rpc.Stub)testMobileSignServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
				else
					_endpoint = (String)((javax.xml.rpc.Stub)testMobileSignServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
			}

		}
		catch (javax.xml.rpc.ServiceException serviceException) {}
	}

	public String getEndpoint() {
		return _endpoint;
	}

	public void setEndpoint(String endpoint) {
		_endpoint = endpoint;
		if (testMobileSignServicePortType != null)
			((javax.xml.rpc.Stub)testMobileSignServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);

	}

	public org.apache.ws.axis2.TestMobileSignServicePortType getTestMobileSignServicePortType() {
		if (testMobileSignServicePortType == null)
			_initTestMobileSignServicePortTypeProxy();
		return testMobileSignServicePortType;
	}

	public void setCertificateInitials(java.lang.String phoneNumber, java.lang.Integer iOperator) throws java.rmi.RemoteException{
		if (testMobileSignServicePortType == null)
			_initTestMobileSignServicePortTypeProxy();
		testMobileSignServicePortType.setCertificateInitials(phoneNumber, iOperator);
	}

	public java.lang.String signHash(java.lang.String hashForSign64, java.lang.String displayText, java.lang.String phoneNumber, java.lang.Integer iOperator) throws java.rmi.RemoteException{
		if (testMobileSignServicePortType == null)
			_initTestMobileSignServicePortTypeProxy();
		return testMobileSignServicePortType.signHash(hashForSign64, displayText, phoneNumber, iOperator);
	}

	public java.lang.String getSigningCert() throws java.rmi.RemoteException{
		if (testMobileSignServicePortType == null)
			_initTestMobileSignServicePortTypeProxy();
		return testMobileSignServicePortType.getSigningCert();
	}

	public java.lang.String getSigningCertAttr() throws java.rmi.RemoteException{
		if (testMobileSignServicePortType == null)
			_initTestMobileSignServicePortTypeProxy();
		return testMobileSignServicePortType.getSigningCertAttr();
	}

	public java.lang.String getSigningCertAttrv2() throws java.rmi.RemoteException{
		if (testMobileSignServicePortType == null)
			_initTestMobileSignServicePortTypeProxy();
		return testMobileSignServicePortType.getSigningCertAttrv2();
	}

	public java.lang.String getSignerIdentifier() throws java.rmi.RemoteException{
		if (testMobileSignServicePortType == null)
			_initTestMobileSignServicePortTypeProxy();
		return testMobileSignServicePortType.getSignerIdentifier();
	}

	public java.lang.String getDigestAlg() throws java.rmi.RemoteException{
		if (testMobileSignServicePortType == null)
			_initTestMobileSignServicePortTypeProxy();
		return testMobileSignServicePortType.getDigestAlg();
	}

}