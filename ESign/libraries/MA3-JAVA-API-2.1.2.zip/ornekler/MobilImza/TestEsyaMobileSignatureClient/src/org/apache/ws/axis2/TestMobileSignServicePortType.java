/**
 * TestMobileSignServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.apache.ws.axis2;

public interface TestMobileSignServicePortType extends java.rmi.Remote {
    public void setCertificateInitials(java.lang.String phoneNumber, java.lang.Integer iOperator) throws java.rmi.RemoteException;
    public java.lang.String signHash(java.lang.String hashForSign64, java.lang.String displayText, java.lang.String phoneNumber, java.lang.Integer iOperator) throws java.rmi.RemoteException;
    public java.lang.String getSigningCert() throws java.rmi.RemoteException;
    public java.lang.String getSigningCertAttr() throws java.rmi.RemoteException;
    public java.lang.String getSigningCertAttrv2() throws java.rmi.RemoteException;
    public java.lang.String getSignerIdentifier() throws java.rmi.RemoteException;
    public java.lang.String getDigestAlg() throws java.rmi.RemoteException;
}
