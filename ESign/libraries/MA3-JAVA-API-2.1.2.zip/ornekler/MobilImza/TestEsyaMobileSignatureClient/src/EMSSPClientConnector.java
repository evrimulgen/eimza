import java.rmi.RemoteException;
import java.security.spec.AlgorithmParameterSpec;

import javax.xml.rpc.ServiceException;
import org.apache.ws.axis2.TestMobileSignServiceLocator;
import org.apache.ws.axis2.TestMobileSignServicePortType;

import tr.gov.tubitak.uekae.esya.api.asn.cms.ESignerIdentifier;
import tr.gov.tubitak.uekae.esya.api.asn.cms.ESigningCertificate;
import tr.gov.tubitak.uekae.esya.api.asn.cms.ESigningCertificateV2;
import tr.gov.tubitak.uekae.esya.api.asn.x509.ECertificate;
import tr.gov.tubitak.uekae.esya.api.common.util.Base64;
import tr.gov.tubitak.uekae.esya.api.crypto.alg.DigestAlg;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.MSSPClientConnector;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.Operator;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.PhoneNumberAndOperator;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.SigningMode;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.UserIdentifier;
import tr.gov.tubitak.uekae.esya.asn.cms.SigningCertificate;
import tr.gov.tubitak.uekae.esya.asn.cms.SigningCertificateV2;

public class EMSSPClientConnector implements MSSPClientConnector
{
	TestMobileSignServiceLocator locator = new TestMobileSignServiceLocator();	
	TestMobileSignServicePortType stub =null;
	
	public EMSSPClientConnector(){
		try {
			stub = locator.getTestMobileSignServiceHttpSoap11Endpoint();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	public void setCertificateInitials(UserIdentifier aUserID) {
		PhoneNumberAndOperator phoneNumberAndOperator = (PhoneNumberAndOperator) aUserID;
		try {
			stub.setCertificateInitials(phoneNumberAndOperator.getPhoneNumber(),phoneNumberAndOperator.getOperator().ordinal());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

    public byte[] sign(byte[] dataToBeSigned, SigningMode aMode, UserIdentifier aUserID, ECertificate aSigningCert, String informativeText, String aSigningAlg,AlgorithmParameterSpec algSpec)
    {
    	if(aMode!=SigningMode.SIGNHASH)
    	{
    		try {
    			throw new Exception("Unsuported signing mode. Only SIGNHASH supported.");
    		} catch (Exception e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    			return null;
    		}
    	}

    	PhoneNumberAndOperator phoneNumberAndOperator = (PhoneNumberAndOperator) aUserID;  	
    	String dataTobeSigned64 = Base64.encode(dataToBeSigned);            
    	Operator opes= phoneNumberAndOperator.getOperator();        	
    	String signatureBase64;
    	try {
    		signatureBase64 = stub.signHash(dataTobeSigned64, informativeText, phoneNumberAndOperator.getPhoneNumber(),opes.ordinal());
    	} catch (RemoteException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    		return null;
    	}
    	if(signatureBase64!=null)
    	{
    		return Base64.decode(signatureBase64);               
    	}
    	return null;
    }
        
	@Override
	public ECertificate getSigningCert() {
		try {
			return  new ECertificate(Base64.decode(stub.getSigningCert()));
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public SigningCertificate getSigningCertAttr() {
		try {
			return  new ESigningCertificate(Base64.decode(stub.getSigningCertAttr())).getObject();
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public SigningCertificateV2 getSigningCertAttrv2() {
		try {
			return  new ESigningCertificateV2(Base64.decode(stub.getSigningCertAttrv2())).getObject();
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public ESignerIdentifier getSignerIdentifier() {
		try {
			return new ESignerIdentifier(Base64.decode(stub.getSignerIdentifier()));
		}  catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public DigestAlg getDigestAlg() {
		try {
			return DigestAlg.fromName(stub.getDigestAlg());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}
