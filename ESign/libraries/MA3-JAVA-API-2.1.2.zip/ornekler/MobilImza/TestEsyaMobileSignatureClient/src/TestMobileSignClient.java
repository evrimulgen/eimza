import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import tr.gov.tubitak.uekae.esya.api.asn.x509.ECertificate;
import tr.gov.tubitak.uekae.esya.api.certificate.validation.policy.PolicyReader;
import tr.gov.tubitak.uekae.esya.api.certificate.validation.policy.ValidationPolicy;
import tr.gov.tubitak.uekae.esya.api.cmssignature.SignableByteArray;
import tr.gov.tubitak.uekae.esya.api.cmssignature.attribute.EParameters;
import tr.gov.tubitak.uekae.esya.api.cmssignature.attribute.IAttribute;
import tr.gov.tubitak.uekae.esya.api.cmssignature.attribute.SigningTimeAttr;
import tr.gov.tubitak.uekae.esya.api.cmssignature.signature.BaseSignedData;
import tr.gov.tubitak.uekae.esya.api.cmssignature.signature.ESignatureType;
import tr.gov.tubitak.uekae.esya.api.common.util.LicenseUtil;
import tr.gov.tubitak.uekae.esya.api.crypto.alg.SignatureAlg;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.MobileSigner;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.Operator;
import tr.gov.tubitak.uekae.esya.api.infra.mobile.PhoneNumberAndOperator;
import tr.gov.tubitak.uekae.esya.asn.util.AsnIO;


public class TestMobileSignClient {
	
	private static final Map<Integer, Operator> intToTypeMap = new HashMap<Integer, Operator>();
	static {
	    for (Operator type : Operator.values()) {
	        intToTypeMap.put(type.ordinal(), type);
	    }
	}

	static Operator fromInt(int i) {
		Operator type = intToTypeMap.get(Integer.valueOf(i));
	    if (type == null) 
	        return Operator.TURKCELL;
	    return type;
	}
	
	 static void loadLicense()
     {
		//write license path below
		  FileInputStream fis;
		try {
				fis = new FileInputStream("C:/Users/int2/Desktop/lisans.xml");
				String p = "1.3.15";
	          LicenseUtil.setLicenseXml(fis, p);
	          fis.close();
		} catch (Exception exc){
			// TODO Auto-generated catch block
			exc.printStackTrace();
		}		 
     }    
	/**
	 * @param args
	 */
	public static void main(String[] args) {	
		 loadLicense();
         String filePath = "C:/Users/int2/Desktop/test.docx"; //document which will be signed
         byte[] contentData;
		try {
			contentData = AsnIO.dosyadanOKU(filePath);
			 String phoneNumber = "05380892868";
	         int mobileOperator = 0;//0-TURKCELL 1-AVEA 2-VODAFONE Operator enum'u içindeki sıra

	         
	         BaseSignedData bs = new BaseSignedData();
	         bs.addContent(new SignableByteArray(contentData));
	         //write policy path below
	         ValidationPolicy validationPolicy = PolicyReader.readValidationPolicy(new FileInputStream("C:/Users/int2/Desktop/policy.xml"));
	         HashMap<String, Object> params = new HashMap<String, Object>();
	         
	         //In real system, validate certificate by giving parameter "true" instead of "false"
	         params.put(EParameters.P_VALIDATE_CERTIFICATE_BEFORE_SIGNING,false);
	         params.put(EParameters.P_CERT_VALIDATION_POLICY, validationPolicy);
	         
	         //Since SigningTime attribute is optional,add it to optional attributes list
	         java.util.List<IAttribute> optionalAttributes = new ArrayList<IAttribute>();	         
	         optionalAttributes.add(new SigningTimeAttr(Calendar.getInstance()));
	                 	         
	         PhoneNumberAndOperator phoneNumberAndOperator = new PhoneNumberAndOperator(phoneNumber,fromInt(mobileOperator));
	         EMSSPClientConnector emsspClientConnector = new EMSSPClientConnector();
	         emsspClientConnector.setCertificateInitials(phoneNumberAndOperator);

	         ECertificate signerCert = null;
	         MobileSigner mobileSigner = new MobileSigner(emsspClientConnector, phoneNumberAndOperator, signerCert, "Dosya imzalanacak",SignatureAlg.RSA_SHA1.getName(),null);
	         bs.addSigner(ESignatureType.TYPE_BES,signerCert,mobileSigner, optionalAttributes, params);

	         AsnIO.dosyayaz(bs.getEncoded(), filePath+".p7s");
		} catch (Exception exc) {
			// TODO Auto-generated catch block
			exc.printStackTrace();
		}        
	}

}
